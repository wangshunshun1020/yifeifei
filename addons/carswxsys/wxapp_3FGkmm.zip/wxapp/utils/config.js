
class Config{
    constructor(){

    }
}
Config.baseUrl = 'https://facars.site100.cn';
//Config.baseUrl = 'http://fast.cn:88';
Config.addonUrl = '/addons/carswxsys/';

//Config.restUrl = 'https://facars.site100.cn/addons/carswxsys/';
Config.onPay=true;  //是否启用支付
 
export {Config};
